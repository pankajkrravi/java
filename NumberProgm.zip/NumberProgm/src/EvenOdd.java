import java.util.Scanner;

// Write a program to check given number is EVEN or ODD?
public class EvenOdd {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number check even or odd");
		int num = s.nextInt();
		if (num % 2 == 0) {
			System.out.println(num + " is Even number");
		} else {
			System.out.println(num + "  is Odd  number");
		}
	}
}