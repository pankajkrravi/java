import java.util.Scanner;

// Write program weather to find range of STRONG NUMBER?
public class StrongRange {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a Range");
		int range = ss.nextInt();
		for (int i = 1; i <= range; i++) {
			int num = i;
			int sum = 0;
			int t = num;
			while (num != 0) {
				int r = num % 10;
				sum = sum + fact(r);
				num = num / 10;
			}
			if (sum == t)
				System.out.println(t + " is a strong number");
		}
	}

	private static int fact(int r) {
		int fact = 1;
		while(r>0)
		{
			fact=fact*r;
			r--;
		}
		return fact;
	}
}