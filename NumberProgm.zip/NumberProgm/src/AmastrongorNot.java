import java.util.Scanner;

// Write a Program to check the given number is ARMSTRONG or not?
public class AmastrongorNot {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter number");
		int n = ss.nextInt();
		boolean r = isAmstrong(n);
		if (r)
			System.out.println("Given number is amstrong number");
		else
			System.out.println("GIven number is not amstrong number");
	}

	static int countDigit(int num) {
		int count = 0;
		while (num > 0) {
			count++;
			num = num / 10;
		}
		return count;
	}

	static int pow(int n, int p) {
		int pw = 1;
		while (p > 0) {
			pw = pw * n;
			p--;
		}
		return pw;
	}

	private static boolean isAmstrong(int x) {
		int nd = countDigit(x);
		int t = x;
		int sum = 0;
		while (t > 0) {
			int r = t % 10;
			sum = sum + pow(r, nd);
			t = t / 10;
		}
		if (sum == x)
			return true;
		else
			return false;
}
}