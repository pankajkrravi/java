import java.util.Scanner;

// Write a program to Swap two numbers without using 3rd variable?
public class SwapWith3rdvar {
	public static void main(String[] args) {
		Scanner sa = new Scanner(System.in);
		System.out.println("Enter two number to swap");
		int p = sa.nextInt();
		int q = sa.nextInt();
		System.out.println("Before swaping a=" + p +"b= " + q);
		int temp;
		temp = p;
		p=q;
		q= temp;
		
		System.out.println("After swaping a = " + p + "b= " + q);
	}
}
