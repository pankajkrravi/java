import java.util.Scanner;

// Write a program to find the FACTORIAL of a given RANGE of numbers?
public class FactRange {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter factorial ranga number");
		int num = ss.nextInt();
		for(int i=1;i<=num;i++)
		{
			System.out.println(i+" ! ="+fact(i));
		}
		//fact(num);
	}

	private static int fact(int num) {
		int fact = 1;
		while (num > 0) {
			fact = fact * num;
			num--;
		}
		return fact;

	}
}
