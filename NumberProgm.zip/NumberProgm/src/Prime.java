import java.util.Scanner;
//Write a program to display PRIME NUMBERS from 1 to n?
public class Prime {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = ss.nextInt();
		System.out.println("Prome number between 1 and " + num);
		// loop through the numbers one by one
		for (int i = 1; i < num; i++) {
			boolean isPrime = true;
			// check to see if the number is prime
			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					isPrime = false;
					break;
				}
			}
			if (isPrime) {
				System.out.println(i + " ");
			}
		}
	}
}
