import java.util.Scanner;

// Write a program to REVERSE the number?
public class ReverseNumber {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a number for reverse");
		int num = ss.nextInt();
		int rev = 0;
		while (num != 0) {
			int r = num % 10;
			rev = rev * 10+ r ;
			num = num / 10;
		}
		System.out.println(" Reverse ="+rev);
	}
}
