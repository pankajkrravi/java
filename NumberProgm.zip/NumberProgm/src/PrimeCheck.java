import java.util.Scanner;

//Write a program to check whether the given number is PRIME or not?
public class PrimeCheck {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = ss.nextInt();
		int i;
		if (n == 1){
			System.out.println("Prime number");
		}
		for (i = 2; i < n; i++) {
			if (n % i == 0)
				System.out.println("not a prime");
			break;
		}
		if (n == i)
			System.out.println("prime");
	}
}
