import java.util.Scanner;

// Write a program to check the given number is PRIME PALINDROME or not?
public class primepalindrom {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();
		int t = n;
		int rev = 0;
		int i;
		while (n != 0) {
			int r = n % 10;
			rev = rev * 10 + r;
			n = n / 10;
		}
		if (rev == t) {
			for (i = 2; i < rev; i++) {
				if (rev % i == 0) {
					System.out.println("not a prime palindrom");
					break;
				}
			}
			if (rev == i)
				System.out.println(t + " is a prime palindrom");
		} else
			System.out.println(t + " not a prime palindrom");
	}
}
