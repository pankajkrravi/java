import java.util.Scanner;

// Write a program to find SUM OF PRIME numbers?
public class PrimeSum {
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter range to print sum of prime numbers");
		int range = sc.nextInt();
		int sum = 0;
		for (int i = 1; i < range; i++) 
		{
			if (isprime(i))
				sum = sum + i;
		}
		System.out.println(sum);
	}

	public static boolean isprime(int num) 
	{
		if (num == 1)
			return false;
		for (int i = 2; i < num; i++) 
		{
			if (num % i == 0) 
			{
				return false;
			}
		}
		return true;
	}

}
