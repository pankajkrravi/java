import java.util.Scanner;

// Write a program to display RANGE of PERFECT NUMBERS?
public class RangePerfectNumber {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = ss.nextInt();
		for (int num = 1; num <= n; num++)
		{
			int sum = 1;
			for (int j = 2; j <= num / 2; j++) {
				if (num % j == 0)
					sum = sum + j;
			}
				if (sum == num) 
				{
					System.out.println(num + " is perfect number");
				}
			}
	}
}


//Perfect number, a positive integer that is equal to the sum of its proper
//divisors. The smallest perfect number is 6, which is the sum of 1, 2, and 3.