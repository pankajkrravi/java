import java.util.Scanner;

// Write a program to find the FACTORIAL of a given number?
public class Factorial {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a number to find factorial");
		int num=ss.nextInt();
		int fact=1;
		for(int i=num;i>=1;i--)
		{
			fact=fact*i;
		}
		System.out.println(+num+"! ="+ fact);
	}
}
