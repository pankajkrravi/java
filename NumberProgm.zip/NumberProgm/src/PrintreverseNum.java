import java.util.Scanner;
// Write a program to Print REVERSE of N to 1 numbers?
public class PrintreverseNum {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int n=sc.nextInt();
		for(int i=n;i>=1;i--)
		{
			System.out.println(i);
		}
	}

}
