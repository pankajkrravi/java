import java.util.Scanner;
//Write a program to display MULTIPLICATION table?
public class Multiplicationab1 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enbter numbar");
		int num = s.nextInt();
		for (int i = 1; i <= 10; i++) {
			System.out.println(num + "*" + i + "=" + num * i);
		}
	}
}
