import java.util.Scanner;

public class PerfectNumOrNot {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter number");
		int num = ss.nextInt();
		int sum = 0;
		for (int i = 1; i <= num / 2; i++) {
			if (num % i == 0)
				sum = sum + i;
		}
		if(sum==num)
		{
			System.out.println(num+" is a perfect number");
		}
		else{
			System.out.println(num+" is not perfect nummber");
		}
	}

}
