import java.util.Scanner;

public class Gcd {
    public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter two numbers");
		int a=s.nextInt();
		int b=s.nextInt();
		int result=hcf(a,b);
		System.out.println("GCD/ HCF"+result);
	}

	private static int hcf(int a, int b) {
      if(a<b)
    	  return hcf(b,a);
      if(b==0)
    	  return a;
		return hcf(b,a%b);
	}
}
