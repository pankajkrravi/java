import java.util.Scanner;

// Write a program to display FIBONACCI series of a number?
public class Fibonacci {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter the number");
		int num = ss.nextInt();
		int a = 0, b = 1, c = 0;
		System.out.println("Fibinacci series upto "+num);
		for (int i = 1; i <= num; i++) {
			a=b;
			b=c;
			c=a+b;
			System.out.println(c);
		}
	}
}
