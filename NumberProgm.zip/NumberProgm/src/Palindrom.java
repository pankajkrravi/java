import java.util.Scanner;

// Write a program to check the given number is PALINDROME or not?
public class Palindrom {
	public static void main(String[] args) {
		Scanner sd = new Scanner(System.in);
		System.out.println("Enter a nuber");
		int num = sd.nextInt();
		int rev = 0;
		int t=num;
		while (num != 0) {
			int r = num % 10;
			rev = rev* 10 + r ;
			num = num / 10;
		}
		if(t==rev)
			System.out.println(t+" is palindronm");
		else
			System.out.println(t+" is not palindrom");
	}

}
