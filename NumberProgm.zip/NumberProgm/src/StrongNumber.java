import java.util.Scanner;

// Write program to check the given number is STRONG or not?
public class StrongNumber {
	public static void main(String[] args) {
		Scanner ss = new Scanner(System.in);
		System.out.println("Enter a number to check strong");
		int num = ss.nextInt();
		int n = num;
		int sum = 0;
		while (num != 0) {
			int r = num % 10;
			sum = sum + fact(r);
			num = num / 10;
		}
		if (n == sum)
			System.out.println(n+" = "+sum+" STRONG number");
		else
			System.out.println(n+"!= "+sum+" NOT STRONG number");
	}

	private static int fact(int r) {
		int fact = 1;
		while (r > 0) {
			fact = fact * r;
			r--;
		}
		return fact;
	}
}
