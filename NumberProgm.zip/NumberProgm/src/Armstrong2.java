import java.util.Scanner;

// Write a Program to display the range of ARMSTRONG numbers?
public class Armstrong2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();
		for (int i = 1; i <= n; i++) {
			boolean r = isAmstrong(n);
			if (r)
				System.out.println(i + " is Amstronh");
		}
	}

	static int countDigit(int n) {
		int count = 0;
		while (n > 0) {
			count++;
			n = n / 10;
		}
		return count;
	}

	static int pow(int n, int p) {
		int pw = 1;
		while (p > 0) {
			pw = pw * n;
			p--;
		}
		return pw;
	}
	private static boolean isAmstrong(int x) {
		int nd = countDigit(x);
		int t=x;
		int sum=0;
		while(t>0)
		{
			int r=t%10;
			sum=sum+pow(r, nd);
			t=t/10;
		}
		if(sum==x)
			return true;
		else
			
		return false;
}
}